favorite_numbers={'Arif':7,'Arik':4,'Abu':52,'Kazi':24,'Jim':91}
for k,v in favorite_numbers.items():
    print('{}\'s favorite number is {}'.format(k,v))