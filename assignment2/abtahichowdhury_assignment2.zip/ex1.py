person={'first_name':'Arik','last_name':'Idrisy','age':19,'city':'New York City'}
print(person['first_name'])
print(person['last_name'])
print(person['age'])
print(person['city'])