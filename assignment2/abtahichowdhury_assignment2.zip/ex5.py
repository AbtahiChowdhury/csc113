rivers={'Nile':'Egypt','Yellow':'China','Amazon':'Brazil'}
for k,v in rivers.items():
    print('The {} river runs through {}'.format(k,v))
print('\n')
for k in rivers.keys():
    print(k)
print('\n')
for v in rivers.values():
    print(v)