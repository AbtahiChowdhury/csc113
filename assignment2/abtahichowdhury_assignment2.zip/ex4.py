Glossary={'for loop':'an iterated loop that runs for a defined amount of iterations','while loop':'a loop that will always run while the condition is true','break':'exit out of the current loop','if':'run the block of code if the condition is true','list':'holds a list of objects of any one data type'}

for k,v in Glossary.items():
    print('{}: {}\n'.format(k,v))