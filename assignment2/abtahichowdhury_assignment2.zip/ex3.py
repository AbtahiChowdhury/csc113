Glossary={'for loop':'an iterated loop that runs for a defined amount of iterations','while loop':'a loop that will always run while the condition is true','break':'exit out of the current loop','if':'run the block of code if the condition is true','list':'holds a list of objects of any one data type'}

print('for loop: {}\n'.format(Glossary['for loop']))
print('while loop: {}\n'.format(Glossary['while loop']))
print('break: {}\n'.format(Glossary['break']))
print('if: {}\n'.format(Glossary['if']))
print('list: {}\n'.format(Glossary['list']))
