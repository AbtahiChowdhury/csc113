x=['Jalapeno Pizza','Mushroom Pizza','Deep Dish Pizza']
for i in x:
    print('I like {}'.format(i))
print('I really love pizza!')