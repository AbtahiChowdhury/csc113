x=[i for i in range(1,21,2)]
for j in x:
    print(j)