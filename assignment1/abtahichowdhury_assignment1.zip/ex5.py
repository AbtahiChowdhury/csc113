x=[i for i in range(1,1000001)]
print('Min value: {}'.format(min(x)))
print('Max value: {}'.format(max(x)))
print('Sum of all values from 1-1000000: {}'.format(sum(x)))