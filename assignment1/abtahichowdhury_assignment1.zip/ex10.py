a=[i**3 for i in range(1,12)]
b=a[:3]
c=a[4:7]
d=a[-3:]
print(a)
print(b)
print(c)
print(d)