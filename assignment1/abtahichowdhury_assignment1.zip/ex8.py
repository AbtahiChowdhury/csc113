x=[]

for i in range(1,11):
    x.append(i**3)
    
for j in x:
    print(j)