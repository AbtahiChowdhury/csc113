x=[i for i in range(0,31,3)]
for j in x:
    print(j)