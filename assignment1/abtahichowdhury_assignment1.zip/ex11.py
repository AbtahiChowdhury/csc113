my_pizzas=['Jalapeno Pizza','Mushroom Pizza','Deep Dish Pizza']
friend_pizzas=my_pizzas[:]
my_pizzas.append('Grilled Chicken Pizza')
friend_pizzas.append('Plain Pizza')

print('My favorite pizzas are:\n')
print(my_pizzas)
print('\nMy friend\'s favorite pizzas are:\n')
print(friend_pizzas)