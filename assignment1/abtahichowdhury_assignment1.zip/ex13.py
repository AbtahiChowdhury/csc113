foods=('chick peas','beans','grilled chicken','mushrooms','soap')
for i in foods:
    print(i,end=', ',flush=True)
#foods[0]='salad'
print('\n')
foods=('chick peas','beans','grilled chicken','salad','bagel')
for i in foods:
    print(i,end=', ',flush=True)
print('\n')