x=['cat','dog','fish']
for i in x:
    print('A {} would make a great pet.'.format(i))
print('All three are common household pets.')